/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_term_relationships`; */
/* PRE_TABLE_NAME: `1707751579_wp_term_relationships`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1707751579_wp_term_relationships` ( `object_id` bigint(20) unsigned NOT NULL DEFAULT '0', `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0', `term_order` int(11) NOT NULL DEFAULT '0', PRIMARY KEY (`object_id`,`term_taxonomy_id`), KEY `term_taxonomy_id` (`term_taxonomy_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1707751579_wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES (9,2,0),(21,3,0),(886,5,0),(1392,3,0),(1393,3,0),(1394,3,0),(1395,3,0),(1529,3,0),(1530,3,0),(1531,3,0),(1532,3,0),(1533,3,0),(1534,3,0),(1655,9,0),(1695,1,0),(1695,9,0),(1695,11,0),(1738,7,0),(1741,9,0),(1741,11,0),(1753,1,0),(1753,9,0),(1753,11,0),(1755,1,0),(1755,9,0),(1755,11,0),(1757,1,0),(1757,9,0),(1757,11,0),(1759,1,0),(1759,9,0),(1759,11,0),(1761,1,0),(1761,9,0),(1761,11,0);
