/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wpforms_tasks_meta`; */
/* PRE_TABLE_NAME: `1707751579_wp_wpforms_tasks_meta`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1707751579_wp_wpforms_tasks_meta` ( `id` bigint(20) NOT NULL AUTO_INCREMENT, `action` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL, `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL, `date` datetime NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1707751579_wp_wpforms_tasks_meta` (`id`, `action`, `data`, `date`) VALUES (1,'wpforms_process_forms_locator_scan','W10=','2024-02-03 10:34:31'),(5,'wpforms_admin_notifications_update','W10=','2024-02-09 05:42:01');
